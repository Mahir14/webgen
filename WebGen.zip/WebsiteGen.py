from tkinter import *
import webbrowser
import os

root = Tk()
root.title("Website maker")
root.maxsize(1100,650)
root.minsize(1100,650)

TITLE = Label(root,text="Website Maker",fg="#161648",bg="#fff",font="Fixedsys 28 bold")
TITLE.place(relx=0.5,rely=0.05,anchor='center')

TABTXT=Label(root,text="Tab title",fg="#161648",bg="#fff",font="Fixedsys 20")
TABTXT.place(relx=0.01,rely=0.12,anchor='w')
TabBOX = Entry(root, width=57,bg="#fff", font="System 20")
TabBOX.place(relx=0.15,rely=0.12,anchor='w')

#P1
TITLE1txt=Label(root,text="Title",fg="#161648",bg="#fff",font="Fixedsys 20")
TITLE1txt.place(relx=0.01,rely=0.19,anchor='w')
Title1BOX = Entry(root, width=23,bg="#fff", font="System 18")#Box
Title1BOX.place(relx=0.15,rely=0.19,anchor='w')

Para1txt=Label(root,text="P1",fg="#161648",bg="#fff",font="Fixedsys 20")
Para1txt.place(relx=0.01,rely=0.25,anchor='w')
Para1BOX = Text(root,wrap=WORD ,height=13,width=46,bg="#fff",font="System 14")#Box
Para1BOX.place(relx=0.15,rely=0.38,anchor='w')

#P2
TITLE2txt=Label(root,text="P2 title",fg="#161648",bg="#fff",font="Fixedsys 20")
TITLE2txt.place(relx=0.51,rely=0.19,anchor='w')
Title2BOX = Entry(root, width=23,bg="#fff", font="System 18")#Box
Title2BOX.place(relx=0.65,rely=0.19,anchor='w')

Para2txt=Label(root,text="P2",fg="#161648",bg="#fff",font="Fixedsys 20")
Para2txt.place(relx=0.51,rely=0.25,anchor='w')
Para2BOX = Text(root,wrap=WORD ,height=13,width=46,bg="#fff",font="System 14")#Box
Para2BOX.place(relx=0.65,rely=0.38,anchor='w')

#P3
TITLE3txt=Label(root,text="P3 title",fg="#161648",bg="#fff",font="Fixedsys 20")
TITLE3txt.place(relx=0.01,rely=0.59,anchor='w')
Title3BOX = Entry(root, width=23,bg="#fff", font="System 18")#Box
Title3BOX.place(relx=0.15,rely=0.59,anchor='w')

Para3txt=Label(root,text="P3",fg="#161648",bg="#fff",font="Fixedsys 20")
Para3txt.place(relx=0.01,rely=0.65,anchor='w')
Para3BOX = Text(root,wrap=WORD ,height=13,width=46,bg="#fff",font="System 14")#Box
Para3BOX.place(relx=0.15,rely=0.78,anchor='w')

#Colour settings

BGTIT = Label(root,text="Background colour (0-255)",bg='#fff',fg='#333',font="Fixedsys 20 bold")
BGTIT.place(relx=0.51,rely=0.59,anchor='w')

#Background colour
REDtxt = Label(root,text="RED",bg="#fff",fg='#f00',font="Fixedsys 20")
REDtxt.place(relx=0.51,rely=0.65,anchor='w')
REDbox = Entry(root,width=4,bg="#fff",font="System 20")#Box red
REDbox.place(relx=0.57,rely=0.65,anchor='w')

GRNtxt = Label(root,text="GREEN",bg="#fff",fg='#0f0',font="Fixedsys 20")
GRNtxt.place(relx=0.64,rely=0.65,anchor='w')
GRNbox = Entry(root,width=4,bg="#fff",font="System 20")#Box green
GRNbox.place(relx=0.72,rely=0.65,anchor='w')

BLUtxt = Label(root,text="BLUE",bg="#fff",fg='#00f',font="Fixedsys 20")
BLUtxt.place(relx=0.79,rely=0.65,anchor='w')
BLUbox = Entry(root,width=4,bg="#fff",font="System 20")#Box blue
BLUbox.place(relx=0.86,rely=0.65,anchor='w')

#Text colour
BGTIT = Label(root,text="Text colour (0-255)",bg='#fff',fg='#333',font="Fixedsys 20 bold")
BGTIT.place(relx=0.51,rely=0.72,anchor='w')

wREDtxt = Label(root,text="RED",bg="#fff",fg='#f00',font="Fixedsys 20")
wREDtxt.place(relx=0.51,rely=0.78,anchor='w')
wREDbox = Entry(root,width=4,bg="#fff",font="System 20")#Txt red
wREDbox.place(relx=0.57,rely=0.78,anchor='w')

wGRNtxt = Label(root,text="GREEN",bg="#fff",fg='#0f0',font="Fixedsys 20")
wGRNtxt.place(relx=0.64,rely=0.78,anchor='w')
wGRNbox = Entry(root,width=4,bg="#fff",font="System 20")#Txt green
wGRNbox.place(relx=0.72,rely=0.78,anchor='w')

wBLUtxt = Label(root,text="BLUE",bg="#fff",fg='#00f',font="Fixedsys 20")
wBLUtxt.place(relx=0.79,rely=0.78,anchor='w')
wBLUbox = Entry(root,width=4,bg="#fff",font="System 20")#Txt blue
wBLUbox.place(relx=0.86,rely=0.78,anchor='w')

COPR = Label(root,text="MahirTech MMXIX",bg="red",fg="#fff",font="Fixedsys 4")
COPR.place(relx=0.99,rely=0.99,anchor="se")

def getValues(p):
    if p == 0.0: return TabBOX.get()
    elif p==1.0: return Title1BOX.get()
    elif p==1.5: return Para1BOX.get('1.0','end')
    elif p==2.0: return Title2BOX.get()
    elif p==2.5: return Para2BOX.get('1.0','end')
    elif p==3.0: return Title3BOX.get()
    elif p==3.5: return Para3BOX.get('1.0','end')
    elif p==4.0: return REDbox.get()
    elif p==4.5: return GRNbox.get()
    elif p==5.0: return BLUbox.get()
    elif p==5.5: return wREDbox.get()
    elif p==6.0: return wGRNbox.get()
    elif p==6.5: return wBLUbox.get()

def loadValues():
    RED = 0; REDc = 0
    BLU = 0; BLUc = 0
    GRN = 0; GRNc = 0

    htm = open('Website/YourWebsite.html','w+')
    htm.write("<!DOCTYPE html>\n")
    htm.write("\n")
    htm.write("<head><title>\n")
    htm.write(str(getValues(0.0)))
    htm.write('</title></head><link rel="stylesheet" href="YourStyle.css"><body>')
    htm.write('<h1 align="center" id="border">\n')
    htm.write(str(getValues(1.0)))
    htm.write("</h1><p>\n")
    htm.write(str(getValues(1.5))+"</p>\n")
    htm.write('<h2 align="left">\n')
    htm.write(str(getValues(2.0)))
    htm.write("</h2><p>\n")
    htm.write(str(getValues(2.5))+"</p>\n")
    htm.write('<h2 align="left">\n')
    htm.write(getValues(3.0))
    htm.write("</h2><p>\n")
    htm.write(str(getValues(3.5))+"</p></body>\n")
    htm.close()

    try: RED = int(getValues(4.0))
    except: RED = 255
    try: GRN = int(getValues(4.5))
    except: GRN = 255
    try: BLU += int(getValues(5.0))
    except: BLU = 255
    
    if RED > 255: RED = 255
    if BLU > 255: BLU = 255
    if GRN > 255: GRN = 255

    try: REDc = int(getValues(5.5))
    except: REDc = 0
    try: GRNc = int(getValues(6.0))
    except: GRNc = 0
    try: BLUc = int(getValues(6.5))
    except: BLUc = 0

    if REDc > 255: REDc = 255
    if BLUc > 255: BLUc = 255
    if GRNc > 255: GRNc = 255
    
    css = open('Website/YourStyle.css','w+')
    css.write("@import url('https://fonts.googleapis.com/css?family=Varela+Round');\n\n")
    css.write('body {background-color: rgb(%s,%s,%d);'%(str(RED),str(GRN),BLU))
    css.write("font-family: 'Varela Round';")
    css.write("color: rgb(%s,%s,%s);}\n\n"%(str(REDc),str(GRNc),str(BLUc)))
    css.write("#border {background-color: rgb(255,255,255,0.1);}")

    webbrowser.open_new_tab("file:///"+os.getcwd()+"/Website/YourWebsite.html")


GENbtn = Button(root,text="Generate",bg="#ccc",fg='#222',font="Fixedsys 20",borderwidth=0,command=lambda: loadValues())
GENbtn.place(relx=0.51,rely=0.85,anchor='w')

root.mainloop()
